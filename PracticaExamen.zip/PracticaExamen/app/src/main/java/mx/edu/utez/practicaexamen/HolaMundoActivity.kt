package mx.edu.utez.practicaexamen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import kotlinx.coroutines.selects.select
import mx.edu.utez.practicaexamen.databinding.ActivityMainBinding

class HolaMundoActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {
    private lateinit var spinner:Spinner
    private lateinit var spinner2: Spinner
    private var selected:Int=0
    private var selected2:Int=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val valorEdit = binding.valor1
        val texto = binding.valor2
        val spinnerEdit= binding.spinner
        val spinnerEdit2= binding.spinner2

        val btn = binding.button
ArrayAdapter.createFromResource(
    this   ,
    R.array.spinner1,
    android.R.layout.simple_spinner_item
).also { adapter ->
    // Specify the layout to use when the list of choices appears
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    // Apply the adapter to the spinner
    spinnerEdit.adapter = adapter
    spinnerEdit2.adapter = adapter
}
        spinnerEdit.onItemSelectedListener=this
        spinnerEdit2.onItemSelectedListener=this

        btn.setOnClickListener{
            val div=valorEdit.text.toString().toDouble()
            when(selected){
                0->{
                        when (selected2){
                            0->{
                                val result=div
                                texto.text=String.format("Resulto: ",result)
                            }
                            1->{
                                val result=div*1.02
                                texto.text=String.format("Resulto: ",result)
                            }
                            2->{
                                val result=div*19.97
                                texto.text=String.format("Resulto: ",result)
                            }
                        }
                    }
                    1->{
                        when (selected2){
                            0->{
                                val result=div*0.98
                                texto.text=String.format("Resulto: ",result)
                            }
                            1->{
                                val result=div
                                texto.text=String.format("Resulto: ",result)
                            }
                            2->{
                                val result=div*19.55
                                texto.text=String.format("Resulto: ",result)
                            }
                        }
                    }
                    2->{
                        when (selected2){
                            0->{
                                val result=div*0.050
                                texto.text=String.format("Resulto: ",result)
                            }
                            1->{
                                val result=div*0.051
                                texto.text=String.format("Resulto: ",result)
                            }
                            2->{
                                val result=div
                                texto.text=String.format("Resulto: ",result)
                            }
                        }
                    }
                }
            }
        }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
        if (p0?.id == spinner.id){
            selected = p2
        }
        if (p0?.id == spinner2.id){
            selected2 = p2
        }
    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
        TODO("Not yet implemented")
    }
}